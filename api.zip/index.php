<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Triage ADOM</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
</head>
<body class="bg-gradient-to-br from-[#2a4693] to-[#4649d6] min-h-screen p-4">
    <div class="max-w-2xl mx-auto">
        <div class="text-center mb-8">
            <h1 class="text-4xl font-bold text-[#2a4693]">Sistema de Triage ADOM</h1>
            <p class="text-xl mt-2 text-[#2a4693]">Evaluaci&oacute;n Inteligente de S&iacute;ntomas</p>
            <div class="mt-4 text-sm bg-[#2a4693] bg-opacity-10 p-4 rounded-lg text-[#2a4693]">
                Este sistema le ayudar&aacute; a determinar la urgencia de los casos m&eacute;dicos recibidos en ADOM. Por favor, complete todos los campos marcados con * para una evaluaci&oacute;n precisa.
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-lg p-6">
            <div class="mb-6 text-sm text-gray-600 border-l-4 border-blue-500 pl-3">
                 La informaci&oacute;n que proporcione ser&aacute; evaluada por un sistema m&eacute;dico inteligente para determinar el nivel de atenci&oacute;n requerido.
            </div>

            <form id="triageForm" class="space-y-6">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Tipo de Consulta *
                        <span class="text-xs text-gray-500 ml-1">(seleccione uno)</span>
                    </label>
                    <div class="grid grid-cols-2 gap-4">
                        <button type="button" onclick="selectConsultType('call')" 
                                class="p-4 border rounded-lg hover:bg-blue-50 focus:ring-2 focus:ring-blue-200" 
                                id="callBtn">
                             Llamada
                        </button>
                        <button type="button" onclick="selectConsultType('platform')" 
                                class="p-4 border rounded-lg hover:bg-blue-50 focus:ring-2 focus:ring-blue-200"
                                id="platformBtn">
                             Plataforma
                        </button>
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            Edad * 
                            <span class="text-xs text-gray-500">(a&ntilde;os)</span>
                        </label>
                        <input type="number" name="age" required min="0" max="120"
                               class="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-200"
                               placeholder="Ej: 35">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            Sexo *
                        </label>
                        <select name="sex" required
                                class="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-200">
                            <option value="">Seleccione...</option>
                            <option value="M">Masculino</option>
                            <option value="F">Femenino</option>
                        </select>
                    </div>
                </div>

                <div id="pregnancyQuestion" class="hidden">
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        &iquest;Est&aacute; en embarazo? *
                        <span class="text-xs text-gray-500">(solo para pacientes femeninas)</span>
                    </label>
                    <div class="grid grid-cols-2 gap-4">
                        <button type="button" onclick="selectPregnancy(true)"
                                class="p-3 border rounded-lg hover:bg-blue-50 focus:ring-2 focus:ring-blue-200">
                            S&iacute;
                        </button>
                        <button type="button" onclick="selectPregnancy(false)"
                                class="p-3 border rounded-lg hover:bg-blue-50 focus:ring-2 focus:ring-blue-200">
                            No
                        </button>
                    </div>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        S&iacute;ntomas Principales *
                        <span class="text-xs text-gray-500">(describa detalladamente)</span>
                    </label>
                    <textarea name="symptoms" required
                              class="w-full p-4 h-32 border rounded-lg focus:ring-2 focus:ring-blue-200"
                              placeholder="Describa todos los s&iacute;ntomas que presenta, cu&aacute;ndo comenzaron, si han empeorado y cualquier otro detalle relevante..."></textarea>
                    <p class="text-xs text-gray-500 mt-1">Mientras m&aacute;s detalles proporcione, m&aacute;s precisa ser&aacute; la evaluaci&oacute;n</p>
                </div>

                <div id="vitalSigns" class="hidden space-y-4">
                    <div class="border-t pt-4">
                        <h3 class="text-lg font-medium text-gray-800 mb-4">
                            Informaci&oacute;n Adicional
                            <span class="text-sm font-normal text-gray-500">(marque lo que corresponda)</span>
                        </h3>
                        
                        <div class="space-y-3">
                            <div class="flex items-center">
                                <input type="checkbox" id="hasFever" class="mr-2">
                                <label for="hasFever" class="text-sm">Presenta fiebre</label>
                                <input type="number" id="temperature" placeholder="��C" step="0.1"
                                       class="ml-4 w-24 p-2 border rounded-lg hidden"
                                       min="35" max="43">
                            </div>

                            <div class="flex items-center">
                                <input type="checkbox" id="hasPain" class="mr-2">
                                <label for="hasPain" class="text-sm">Presenta dolor</label>
                                <input type="number" id="painLevel" placeholder="1-10" min="1" max="10"
                                       class="ml-4 w-24 p-2 border rounded-lg hidden">
                            </div>

                            <div>
                                <input type="checkbox" id="hasBreathingDifficulty" class="mr-2">
                                <label for="hasBreathingDifficulty" class="text-sm">Dificultad para respirar</label>
                            </div>
                            <div>
                                <input type="checkbox" id="hasVomiting" class="mr-2">
                                <label for="hasVomiting" class="text-sm">V&oacute;mito</label>
                            </div>
                            <div>
                                <input type="checkbox" id="hasConsciousnessLoss" class="mr-2">
                                <label for="hasConsciousnessLoss" class="text-sm">P&eacute;rdida de consciencia</label>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="border-t pt-6">
                    <button type="submit" 
                            class="w-full p-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:ring-4 focus:ring-blue-200 transition-colors">
                        Evaluar Triage
                    </button>
                    <p class="text-xs text-gray-500 mt-2 text-center">
                        * Los campos marcados con asterisco son obligatorios
                    </p>
                </div>
            </form>

            <div id="triageResult" class="hidden mt-6"></div>
        </div>

        <div class="mt-4 text-xs text-white/70 text-center">
            En caso de emergencia evidente, direccione a urgencias
        </div>
    </div>

    <script>
        const CONFIG = {
            API_URL: 'api/triage.php'
        };
    </script>
    <script src="js/triage.js"></script>
</body>
</html>